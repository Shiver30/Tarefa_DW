<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="salvar_emprestimo.php" method="post">

        Id aluno: <br>
        <input type="text" name="id_aluno"> <br>

        Id Livro: <br>
        <input type="text" name="id_livro"> <br>

        Data de emprestimo: <br>
        <input type="text" name="emprestimo"> <br>

        Data de devolução: <br>
        <input type="text" name="devolucao"> <br>

        <input type="submit" value="Salvar emprestimo">

    </form>

</body>
</html>