<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="salvar_aluno.php" method="post">
        Nome: <br>
        <input type="text" name="nome"> <br><br>
        
        Matricula: <br>
        <input type="text" name="matricula"> <br><br>

        Curso: <br>
        <input type="text" name="curso"> <br><br>
       
        Turma: <br>
        <input type="text" name="turma"> <br><br>

        Data de nascimento: <br>
        <input type="date" name="nascimento"> <br><br>

        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>

</body>
</html>