<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="salvar_curso.php" method="post">

    Nome do Curso: <br>
    <input type="text" name="nome"> <br>

    Carga Horária: <br>
    <input type="number" name="cg"> <br>

    Ano de inicio: <br>
    <input type="number" name="ano_inicio"> <br>

    <input type="submit" value="Salvar Curso" >

    </form>


</body>
</html>